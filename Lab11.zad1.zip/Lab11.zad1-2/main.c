#include <stdio.h>
#include <windows.h>
int main(int argc, char *argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);
    float alfa = 1.11f;
    float beta = 2.22f;
    float gamma = 3.33f;
    float *ptr = NULL;
    ptr = &beta;
    printf("\n%.3f", beta);
    printf("\n%.3f", *ptr);
    printf("\n%p", ptr);
    printf("\n%p", &beta);
    ptr = &gamma;
    printf("\n%.3f", *ptr);
    *ptr += *ptr;
    printf("\n%.3f", *ptr);
    printf("\n%p", ptr);
    ptr = &alfa;
    printf("\n%.3f", *ptr);
    printf("\n%p", ptr);
    fflush(stdin);
    printf("\n\nNacisnij Enter, aby zakończyć...");
    getchar();
    return 0;
}