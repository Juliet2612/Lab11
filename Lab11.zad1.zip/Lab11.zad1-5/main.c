#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <time.h>
#define SIZE 50
#define RANGE 1000
#define COL 10
void genArr(int n, int arr[], unsigned int range);
int mycompare(const void* arg1, const void* arg2);
void printArr(int arr[], int n);
int main(int argc, char *argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);
    int myArr[SIZE];
    genArr(SIZE, myArr, RANGE);
    puts("Tablica nieposortowana:");
    printArr(myArr, SIZE);
    qsort(myArr, SIZE, sizeof(int), mycompare);
    puts("\n\nTablica posortowana rosnąco:");
    printArr(myArr, SIZE);
    puts("\nNaciśnij Enter, aby zakończyć...");
    fflush(stdin);
    getchar();
    return 0;
}
void genArr(int n, int arr[], unsigned int range) {
    int zarodek;
    time_t tt;
    zarodek = time(&tt);
    srand(zarodek);
    for (int i = 0; i < n; i++) {
        arr[i] = rand() % range;
    }
}

void printArr(int arr[], int n) {
    for (int i = 0; i < n; i++) {
        printf("%5d ", arr[i]);
        if ((i + 1) % COL == 0) putchar('\n');
    }
}

int mycompare(const void* p1, const void* p2) {

    const int* a1 = p1;
    const int* a2 = p2;
    if (*a1 < *a2)
        return -1;
    else if (*a1 == *a2)
        return 0;
    else
        return 1;

}