#include <stdio.h>
#include <stdlib.h>
#define KOD_MIN 32
#define KOD_MAX 255
int main(int argc, char *argv[]) {
    printf("Kody 8-bitowe\n");
    system("chcp 1250");
    for (int ch = KOD_MIN; ch <= KOD_MAX; ch++) {
        printf("\n %x - %c", ch, ch);
    }
    char str[100];
    printf("\nWprowadź łańcuch znaków: ");
    scanf("%s", str);
    printf("\nWrowadziłeś: %s", str);
    printf("\n\nNaciśnij Enter, aby zakończyć...");
    fflush(stdin);
    getchar();
    return 0;
}