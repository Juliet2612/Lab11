#include <stdio.h>
#include <windows.h>
int main(int argc, char *argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);
    int arr[] = {10, 11, 12, 13, 14, 15};
    int *ptr = NULL, size, i;
    size = sizeof(arr) / sizeof(int);
    printf("Zawartość tablicy - ind. rosnąco\n");
    for (i = 0; i < size; i++)
        printf("%d ", arr[i]);
    printf("\n");
    for (i = 0, ptr = arr; i < size; i++)
        printf("%d ", *(ptr + i));
    printf("\n\nZawartość tablicy - ind. malejąco\n");
    for (i = size - 1; i >= 0; i--)
        printf("%d ", arr[i]);
    printf("\n");
    ptr = arr + size;
    for (i = 0; i < size; i++)
        printf("%d ", *(--ptr));
    puts("\n\nNaciśnij Enter, aby zakończyć...");
    fflush(stdin);
    getchar();
    return 0;
}