#include <stdio.h>
#include <windows.h>
#include <stdint.h>
int main(int argc, char *argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);
    void *wsk1;
    int32_t *wsk2;
    double *wsk3;
    int32_t iAlfa = 10, iBeta = 20, iGamma = 30;
    double dAlfa = 1.234, dBeta = 3.456, dGamma = 6.789;
    printf("\n\nwskaźnik na int32_t");
    wsk2 = &iAlfa;
    printf("\nwsk2=\t%p", wsk2);
    printf("\n*wart2=\t%lld", *wsk2);
    wsk2 = &iBeta;
    printf("\nwsk2=\t%p", wsk2);
    printf("\n*wart2=\t%lld", *wsk2);
    wsk2 = &iGamma;
    printf("\nwsk2=\t%p", wsk2);
    printf("\n*wart2=\t%lld\n", *wsk2);
    printf("\n%d", &iAlfa - &iGamma);
    printf("\n%i", (&iAlfa == &iGamma));
    wsk2 = &iAlfa;
    printf("\n*wart2=\t%lld", *wsk2);
    wsk2--;
    printf("\n*wart2=\t%lld", *wsk2);
    wsk2--;
    printf("\n*wart2=\t%lld", *wsk2);
    getchar();
    printf("\n\nwskaźnik na double");
    wsk3 = &dAlfa;
    printf("\nwsk3=\t%p", wsk3);
    printf("\n*wart3=\t%lf", *wsk3);
    wsk3 = &dBeta;
    printf("\nwsk3=\t%p", wsk3);
    printf("\n*wart3=\t%lf", *wsk3);
    wsk3 = &dGamma;
    printf("\nwsk3=\t%p", wsk3);
    printf("\n*wart3=\t%lf\n", *wsk3);
    getchar();printf("\n\nwskaźnik anonimowy\nwymagane rzutowanie przy wyłuskaniu");
    wsk1 = wsk3;
    printf("\nwsk1=\t%p", wsk1);
    printf("\n*wart1=\t%lf", *(double *) wsk1);
    printf("\n\n");
    getchar();
    return 0;
}