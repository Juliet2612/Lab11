#include <stdio.h>
#include <windows.h>

int main(int argc, char *argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);
    printf("Wskażniki - inicjowanie i wyłuskiwanie\n");
    int alfa = 100, beta;
    int *ptr1 = NULL, *ptr2 = NULL;
    printf("ptr1: %p\nptr2: %p\n", ptr1, ptr2);
    ptr1 = &alfa;
    printf("\nptr1: %p\n", ptr1);
    printf("*ptr1= %d\n", *ptr1);
    printf("alfa= %d\n", alfa);
    *ptr1 = 123;
    printf("alfa= %d\n", alfa);
    printf("*ptr1= %d\n", *ptr1);
    ptr2 = &beta;
    *ptr2 = *ptr1;
    printf("beta= %d\n", *ptr2);
    printf("alfa: %d\n", *ptr1 + 200);
    void *ptr3;
    printf("\nptr3: %p\n", ptr3);
    ptr3 = ptr2;
    printf("*ptr3= %d\n", *(int *) ptr3);
    fflush(stdin);
    printf("\nNacisnij Enter, aby zakończyć...");
    getchar();
    return 0;
}